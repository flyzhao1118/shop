<template>

  <div id="J-buy-showcase" class="buy-showcase lazyData">

    <div class="wall-container clearfix">

      <div class="wall-detail-list">

        <div class="wall-list J_scroll_wallbox clearfix">

          <div class="wall-col fl clearfix">

            <div class="clearfix scroll-remove layer-3d scroll-remove0">

              <div class="wall_item">
                <a href="http://m.mogujie.com/x6/wall/book/household?fcid=10055974&amp;title=毛绒玩具&amp;mt=10.1079.r77417" class="imghref" style="border-bottom: 2px solid #fc5087">
                  <div class="item-title-wrap">
                    <div class="tag-wrap">
                      <span>百货</span>
                    </div>
                  </div>
                  <div class="img-detail">
                    <div class="lazyV2" style="padding:50% 0">
                      <img src="http://s18.mogucdn.com/p1/160506/upload_ifqtszldmmzdczjvhazdambqgyyde_315x315.png">
                    </div>
                  </div>
                  <div class="txt-wrap">
                    <div class="title-word">长不大的少女心</div>
                    <div class="desc">我不想 我不想 不想长大~</div>
                  </div>
                </a>
              </div>

            </div>

            <div class="clearfix scroll-remove layer-3d scroll-remove1">

              <div class="wall_item">
                <a href="http://m.mogujie.com/x6/wall/book/household?fcid=51964&amp;title=创意生活&amp;fId=&amp;mt=10.1079.r60619" class="imghref" style="border-bottom: 2px solid #fc5087">
                  <div class="item-title-wrap">
                    <div class="tag-wrap">
                      <span>家居</span>
                    </div>
                  </div>
                  <div class="img-detail">
                    <div class="lazyV2" style="padding:50% 0"><img src="http://s18.mogucdn.com/p1/160307/upload_ie4wgmdfmfqtaojsg4zdambqgqyde_315x315.jpg"></div>
                  </div>
                  <div class="txt-wrap">
                    <div class="title-word">创意生活</div>
                    <div class="desc">生活里，总需要小创意～</div>
                  </div>
                </a>
              </div>

            </div>

          </div>

          <div class="wall-col fl clearfix">

            <div class="clearfix scroll-remove layer-3d scroll-remove0">

              <div class="wall_item">
                <a href="http://m.mogujie.com/x6/wall/book/household?fcid=10055974&amp;title=毛绒玩具&amp;mt=10.1079.r77417" class="imghref" style="border-bottom: 2px solid #fc5087">
                  <div class="item-title-wrap">
                    <div class="tag-wrap">
                      <span>百货</span>
                    </div>
                  </div>
                  <div class="img-detail">
                    <div class="lazyV2" style="padding:50% 0">
                      <img src="http://s17.mogucdn.com/p1/160506/upload_ifrggndfmezdczjvhazdambqmeyde_315x315.png">
                    </div>
                  </div>
                  <div class="txt-wrap">
                    <div class="title-word">长不大的少女心</div>
                    <div class="desc">我不想 我不想 不想长大~</div>
                  </div>
                </a>
              </div>

            </div>

            <div class="clearfix scroll-remove layer-3d scroll-remove1">

              <div class="wall_item">
                <a href="http://m.mogujie.com/x6/wall/book/household?fcid=51964&amp;title=创意生活&amp;fId=&amp;mt=10.1079.r60619" class="imghref" style="border-bottom: 2px solid #fc5087">
                  <div class="item-title-wrap">
                    <div class="tag-wrap">
                      <span>家居</span>
                    </div>
                  </div>
                  <div class="img-detail">
                    <div class="lazyV2" style="padding:50% 0">
                      <img src="http://s17.mogucdn.com/p1/160325/upload_ie4gen3eguzdmnbyg4zdambqgiyde_315x315.png">
                    </div>                 
                  </div>
                  <div class="txt-wrap">
                    <div class="title-word">创意生活</div>
                    <div class="desc">生活里，总需要小创意～</div>
                  </div>
                </a>
              </div>

            </div>

          </div>

        </div>

      </div>

    </div>

  </div>


</template>
