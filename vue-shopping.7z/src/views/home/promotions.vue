<template>

  <div id="J-buy-promotions" class="buy-promotions lazyData">

    <div class="module-wrap promotions-wrap">

      <div class="module-content m-flex">

        <div class="item-flex flex-160">

          <div class="item-mod-main">

            <a class="item-promotion" v-link="{name:'timelimit'}">
              <div class="fast-title m-flex m-flex-center">
                <i class="fast-tag"></i>
                <span>限时快抢</span>
              </div>
              <div class="time-count">
                <div class="J_Countdown">
                  <span><em>09</em></span>:
                  <span><em>36</em></span>:
                  <span><em>45</em></span>
                </div>
              </div>
              <div class="promotion-tag m-flex m-flex-center">
                <div class="p-goods-title item-flex">
                  <span>快抢价</span>
                  <br>39元
                </div>
              </div>
              <div class="item-image">
                <img src="http://s18.mogucdn.com/p1/160425/7ldo7_ie4tqnbvg4zdimzshazdambqgqyde_640x640.jpg_320x999.jpg_235x235.jpg" alt="">
              </div>
            </a>

          </div>

        </div>

        <div class="item-flex flex-215">

          <a class="item-promotion mb10" href="http://www.mogujie.com/tuan/mihoyo/index?mt=10.831.r69883">
            <img src="http://s7.mogucdn.com/p1/160314/2p_ifrtamjrgjstoyrug4zdambqhayde_428x174.jpg" alt="">
          </a>

          <div class="item-promotion m-flex">
            <a class="item-flex mr10" href="http://act.mogujie.com/hongzhang9kuai9?ismobile=1&amp;mt=10.831.r71125">
              <img src="http://s8.mogucdn.com/p1/160401/ec_ie4dindfmyydoodbg4zdambqgiyde_209x174.jpg" alt="">
            </a>
            <a class="item-flex" href="http://www.mogujie.com/tuan/handschoph5?gobacktuan=true&amp;mt=10.831.r69884">
              <img src="http://s7.mogucdn.com/p1/160404/h6_ifrgkyjwhftdontcg4zdambqmeyde_209x174.jpg" alt=""> </a>
          </div>

        </div>

      </div>

    </div>

  </div>

</template>
