<style></style>
<template>

  <div class="module_row module_row_18135 MOD_ID_9887">

    <div class="mod_row MCUBE_MOD_ID_9887">

      <div class="module-wrapper module-B">

        <div class="nav-box">
          <div class="nav-box-wrapper">
            <ul class="nav-list">
              <li class="nav-item text-right"></li>
              <li class="nav-item text-left"></li>
              <li class="nav-item">
                <div class="seckill-time">16:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">19:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">21:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">22:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">23:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">10:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item active">
                <div class="seckill-time">12:00</div>
                <div class="seckill-status">已开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">13:00</div>
                <div class="seckill-status">快抢中</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">16:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">19:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">21:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">22:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">23:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">00:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">10:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">12:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item ">
                <div class="seckill-time">13:00</div>
                <div class="seckill-status">即将开抢</div>
              </li>
              <li class="nav-item text-right"></li>
              <li class="nav-item text-left"></li>
            </ul>
            <div class="active-arrow"></div>
          </div>
        </div>

        <div class="content-box">

          <div class="content">

            <div class="content-header">
              <div class="header-list " id="header-list-0">
                <div class="header-title">还有宝贝可以继续抢购哦</div>
                <div class="header-countdown"></div>
              </div>
            </div>

            <div class="content-body">
              <div class="item-list">
                <div class="J_dynamic-remove J_mod_show">

                  <a class="J_mogu-link item soldout" href="http://m.mogujie.com/x6/detail/18ojc0c">
                    <span class="corner-tag"></span>
                    <div class="item-image lazy-load">
                    </div>
                    <div class="item-detail">
                      <div class="title text_hide yahei">可换颜色码数杨幂同款单鞋</div>
                      <div class="price text_hide">
                        <span>快抢价<span class="cur">¥39.90</span></span>
                        <del class="old">¥84.29</del>
                      </div>
                      <div class="status-text yahei">已售100件</div>
                      <div style="position: absolute; bottom: 2px;">
                        <span class="buy-btn soldout ">原价购买</span>
                      </div>
                    </div>
                  </a>

                  <a class="item onecent lazy-load" href="http://act.mogujie.com/fastbuy/onecent?ismobile=1&amp;mt=12.1112.r90414.3097&amp;acm=1.mce.2.1112.0.0.3097_90414"></a>

                  <a class="J_mogu-link item ongoing" href="http://m.mogujie.com/rush/seckill/15omm?itemId=18ph9ma">
                    <span class="corner-tag" style="background-image:url();"></span>
                    <div class="item-image lazy-load"></div>
                    <div class="item-detail">
                      <div class="title text_hide yahei">T恤+牛仔群套装</div>
                      <div class="price text_hide"><span>快抢价<span class="cur">¥49.00</span></span><del class="old">¥93.00</del></div>
                      <div class="status-bar-box">
                        <div class="status-bar" style="width: 73%;"></div>
                        <span class="status-bar-text text_hide">已抢购146件</span>
                      </div>
                      <div style="position: absolute; bottom: 2px;">
                        <span class="buy-btn ongoing ">立即抢购</span>
                        <span class="left-text">仅剩54件</span>
                      </div>
                    </div>
                  </a>

                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>

  </div>

</template>

<script>

  export default {
      data () {
        return {

        }
      }
  }

</script>
