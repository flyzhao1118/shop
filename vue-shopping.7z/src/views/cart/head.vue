<template>

  <header class="ui-head-bar">
    <a class="arr" href="javascript:void(history.back());">
      <i class="icon-back"></i>
    </a>
    <p class="title">购物车</p>
    <span class="badge icon-uniE810 badge-car" v-link="{name:'cart'}"></span>
  </header>

</template>
