
<style>
  .fadeIn {
    -webkit-animation: fadeIn .8s ease both;
    animation: fadeIn .8s ease both;
  }
  @-webkit-keyframes fadeIn {
    0% {
      opacity: 0
    }

    100% {
      opacity: 1
    }
  }

  @keyframes fadeIn {
    0% {
      opacity: 0
    }

    100% {
      opacity: 1
    }
  }
</style>
<template>

  <div class="hot-sale">
    <div class="hot-sales-mod clearfix">
      <div class="new-goods hot-sale-cell flex340">
        <a href="http://act.mogujie.com/nzxianshi?ismobile=1&amp;mt=10.639.r63371">
          <img class="fadeIn" src="http://s17.mogucdn.com/p1/160204/upload_ifrdizdggzqtsmjygyzdambqmeyde_339x381.jpg" alt="上衣新品抢鲜价"></a>
        <div class="count-down-area">距离结束还剩<span class="J_Countdown"><em>14</em>:<em>40</em>:<em>10</em></span></div>
      </div>
      <div class="flex410">
        <div class="hot-goods hot-sale-cell">
          <a href="http://www.mogujie.com/x6/markets/clothing/shop/stylebrand?mt=10.532.r41200">
            <img class="fadeIn" src="http://s10.mogucdn.com/p1/160309/fn_ie4dqzbvgu2ggmbtg4zdambqgiyde_410x190.jpg" alt="品质风格">
          </a>
        </div>
        <div class="like-photo hot-sale-cell">
          <a href="http://m.mogujie.com/x6/dmp/collocation/index/126?mt=10.532.r64628">
          <img class="fadeIn" src="http://s6.mogucdn.com/p1/160309/fn_ie3weolgme2ggmbtg4zdambqgayde_410x190.jpg" alt="精选搭配">
        </a>
        </div>
      </div>
    </div>
  </div>

</template>
